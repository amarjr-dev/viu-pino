# viu-pino

Pino adapter for Viu logging (Kafka + Loki)

## Quer ver o erro? → Joga no Viu.

## Installation

```bash
npm install viu-pino
# or
yarn add viu-pino
# or
bun add viu-pino
```

## Quick Usage

```typescript
import { ViuPino } from 'viu-pino';

const logger = ViuPino.getInstance({
  serviceName: 'my-api',
  environment: 'development',
  kafkaBrokers: 'localhost:9092',
  kafkaTopic: 'logs.app.raw',
});

await logger.initialize();

logger.info('User logged in', { userId: '123' });
logger.error('Payment failed', error);
```

## Production Usage with Kafka Authentication

```typescript
import { ViuPino } from 'viu-pino';

const logger = ViuPino.getInstance({
  serviceName: 'my-api',
  environment: 'production',
  kafkaBrokers: 'viu-kafka.seudominio.com:9092',
  kafkaUsername: 'viu_tenant123abc',
  kafkaPassword: 'sua-senha-kafka',
  kafkaSaslMechanism: 'SCRAM-SHA-256',
  kafkaSecurityProtocol: 'SASL_SSL',
});

await logger.initialize();

logger.info('User logged in', { userId: '123' });
```

## Environment Variables

```bash
# Basic config
export VIU_SERVICE_NAME=my-api
export VIU_ENVIRONMENT=production
export VIU_KAFKA_BROKERS=viu-kafka.seudominio.com:9092
export VIU_KAFKA_TOPIC=logs.tenant-id

# Kafka authentication (required in production)
export VIU_KAFKA_USERNAME=viu_tenant123abc
export VIU_KAFKA_PASSWORD=sua-senha-kafka
export VIU_KAFKA_SASL_MECHANISM=SCRAM-SHA-256
export VIU_KAFKA_SECURITY_PROTOCOL=SASL_SSL
```

## Express Middleware

```typescript
import express from 'express';
import { viuCorrelationMiddleware } from 'viu-pino/express';

const app = express();

app.use(viuCorrelationMiddleware({
  serviceName: 'my-api',
  environment: 'production',
}));
```

## Configuration

| Option | Description | Default |
|--------|-------------|---------|
| `serviceName` | Service name | Required |
| `environment` | Environment | `development` |
| `kafkaBrokers` | Kafka brokers | `localhost:9092` |
| `kafkaTopic` | Kafka topic | `logs.app.raw` |
| `kafkaUsername` | SASL username | Optional |
| `kafkaPassword` | SASL password | Optional |
| `kafkaSaslMechanism` | SASL mechanism | `SCRAM-SHA-256` |
| `kafkaSecurityProtocol` | Security protocol | `SASL_SSL` |
| `level` | Log level | `info` |
| `prettyPrint` | Pretty print logs | `false` |

## Documentation

See [docs.viu.com/nodejs](https://docs.viu.com/nodejs) for more details.

## License

MIT
